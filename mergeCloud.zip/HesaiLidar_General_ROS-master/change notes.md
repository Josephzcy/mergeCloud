# HesaiLidar_General_ROS

星期二, 17. 十一月 2020 15:25下午 
##version
PandarGeneralROS_1.0.1 

##modify
1. first update

星期三, 09. 十二月 2020 16:25下午 
##version
PandarGeneralROS_1.1.1 

##modify
1. support multiple sensors
2. support GPS port not hard bind 

星期三, 16. 十二月 2020 20:25下午 
##version
PandarGeneralROS_1.1.2

##modify
1. modify msg data size 

星期二, 05. 一月 2021 17:00下午 
##version
PandarGeneralROS_1.1.3

##modify
1. fix the problem in playing rosbag when timestamp is realtime
2. optimize computational efficiency 
3. change readme