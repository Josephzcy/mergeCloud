
#include "tsf.h"
#include <iostream>

int main()
{
	SetGPSBase(31.2989347, 121.5174345, 14.24);
	Point pt;
	GetLocal(31.2989347, 121.5174345, 14.24, pt);
	std::cout << "GetLocal(31.2989347, 121.5174345, 14.24), return:" << pt.x
		<< "," << pt.y
		<< "," << pt.z
		<< std::endl;
	GetLocal(31.2960762, 121.5175797, 14.52, pt);
	std::cout << "GetLocal(31.2960762, 121.5175797, 14.52), return:" << pt.x
		<< "," << pt.y
		<< "," << pt.z
		<< std::endl;
	return 0;
}